'use client';

import { useSavedRecipes } from '@/hooks/use-saved-recipes';
import RecipeCard from '@/components/recipe-card';
import { Button } from '@/components/ui/button';
import { Trash2, BookmarkX } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Recipe } from '@/lib/types';
import AnimatedGrid from '@/components/animated-grid';

export default function SavedRecipesPage() {
  const { savedRecipes, clearSavedRecipes } = useSavedRecipes();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
        <div className='text-center sm:text-left'>
            <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
                Saved Recipes
            </h1>
            <p className="mt-2 text-lg text-muted-foreground">
                Your collection of culinary inspiration.
            </p>
        </div>

        {savedRecipes.length > 0 && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="mr-2 h-4 w-4" />
                Clear All
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete all
                  of your saved recipes.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={clearSavedRecipes}>
                  Continue
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      {savedRecipes.length > 0 ? (
        <AnimatedGrid className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {savedRecipes.map((recipe: Recipe, index) => (
            <RecipeCard
              key={recipe.name}
              recipe={recipe}
              availableIngredients=""
              index={index}
            />
          ))}
        </AnimatedGrid>
      ) : (
        <div className="mt-16 flex flex-col items-center justify-center text-center">
            <BookmarkX className="h-16 w-16 text-muted-foreground" />
            <h3 className="mt-4 text-2xl font-semibold text-foreground">No Recipes Saved Yet</h3>
            <p className="mt-2 text-muted-foreground">
            Start exploring and save your favorite recipes to see them here.
            </p>
        </div>
      )}
    </div>
  );
}
