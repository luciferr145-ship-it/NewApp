'use client';

import { useState, useTransition } from 'react';
import { motion } from 'framer-motion';
import { getAdjustedIngredients } from "@/app/actions";
import RecipeActions from "@/components/recipe-actions";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { slugify } from "@/lib/utils";
import { Clock, Users, Soup, ChefHat, Loader2 } from "lucide-react";
import Image from "next/image";
import { Recipe } from '@/lib/types';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';

type RecipeViewProps = {
    recipe: Recipe;
    availableIngredients: string;
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
        duration: 0.5
    }
  },
};


export default function RecipeView({ recipe: initialRecipe, availableIngredients }: RecipeViewProps) {
  const [recipe, setRecipe] = useState(initialRecipe);
  const [servings, setServings] = useState(parseInt(initialRecipe.servings.split('-')[0]) || 2);
  const [isPending, startTransition] = useTransition();

  const handleServingsChange = (newServingsValue: number[]) => {
    const newServings = newServingsValue[0];
    setServings(newServings);
    startTransition(async () => {
      if (newServings === (parseInt(initialRecipe.servings.split('-')[0]) || 2)) {
          setRecipe(initialRecipe);
          return;
      }
      const adjustedIngredients = await getAdjustedIngredients(initialRecipe, newServings);
      if (adjustedIngredients.length > 0) {
        setRecipe({ ...recipe, ingredients: adjustedIngredients });
      }
    });
  };

  const placeholder = PlaceHolderImages[slugify(recipe.name).length % PlaceHolderImages.length];
  const originalServings = parseInt(recipe.servings.match(/\d+/)?.[0] ?? '2');

  return (
    <main className="container mx-auto max-w-5xl px-4 py-8">
      <motion.div 
        className="space-y-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
            <Card className="overflow-hidden">
            <CardHeader className="p-0">
                <div className="relative h-64 md:h-96 w-full">
                <Image
                    src={placeholder.imageUrl}
                    alt={recipe.name}
                    fill
                    priority
                    className="object-cover"
                    data-ai-hint={placeholder.imageHint}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-0 left-0 p-6">
                    <h1 className="font-headline text-4xl font-extrabold tracking-tight text-white md:text-5xl">
                    {recipe.name}
                    </h1>
                    <p className="mt-2 max-w-2xl text-lg text-white/90">
                    {recipe.description}
                    </p>
                </div>
                <div className="absolute top-4 right-4">
                    <RecipeActions recipe={initialRecipe} availableIngredients={availableIngredients} />
                </div>
                </div>
            </CardHeader>
            <CardContent className="p-6">
                <div className="mb-6 flex flex-wrap items-center gap-x-6 gap-y-4 text-muted-foreground">
                    <div className="flex items-center gap-2">
                        <Clock className="h-5 w-5 text-accent" />
                        <span>{recipe.cookTimeMinutes} min</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <Users className="h-5 w-5 text-accent" />
                        <span>{recipe.servings} servings</span>
                    </div>
                </div>

                <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
                <motion.div variants={itemVariants} className="md:col-span-1">
                    <h2 className="flex items-center gap-2 font-headline text-2xl font-bold">
                        <Soup className="h-6 w-6 text-accent"/>
                        Ingredients
                    </h2>
                    <div className="my-4 space-y-2">
                        <Label htmlFor="servings-slider">Servings: {servings}</Label>
                        <Slider
                            id="servings-slider"
                            min={1}
                            max={originalServings * 2}
                            step={1}
                            value={[servings]}
                            onValueChange={handleServingsChange}
                            disabled={isPending}
                        />
                    </div>
                    {isPending ? (
                        <div className="flex items-center justify-center py-4">
                            <Loader2 className="h-6 w-6 animate-spin text-accent" />
                        </div>
                    ) : (
                        <ul className="mt-4 space-y-2 text-foreground/90 transition-opacity">
                            {recipe.ingredients.map((ingredient, index) => (
                                <li key={index} className="flex items-start">
                                <span className="mr-2 mt-1 block h-1.5 w-1.5 rounded-full bg-accent" />
                                <span>{ingredient}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                </motion.div>
                <motion.div variants={itemVariants} className="md:col-span-2">
                    <h2 className="flex items-center gap-2 font-headline text-2xl font-bold">
                        <ChefHat className="h-6 w-6 text-accent"/>
                        Instructions
                    </h2>
                    <ol className="mt-4 space-y-4">
                    {recipe.instructions.map((step, index) => (
                        <li key={index} className="flex gap-4">
                        <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground font-bold">
                            {index + 1}
                        </div>
                        <p className="pt-1 text-foreground/90">{step}</p>
                        </li>
                    ))}
                    </ol>
                </motion.div>
                </div>
            </CardContent>
            </Card>
        </motion.div>
      </motion.div>
    </main>
  );
}
