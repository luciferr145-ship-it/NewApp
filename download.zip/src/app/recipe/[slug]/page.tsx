import { getRecipeDetails } from "@/app/actions";
import { notFound } from "next/navigation";
import RecipeView from "./recipe-view";

export default async function RecipePage({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: { ingredients: string };
}) {
  const availableIngredients = searchParams.ingredients || '';
  const recipe = await getRecipeDetails(params.slug, availableIngredients);

  if (!recipe) {
    notFound();
  }

  return <RecipeView recipe={recipe} availableIngredients={availableIngredients} />;
}
