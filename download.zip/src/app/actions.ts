'use server';

import { suggestRecipesFromIngredients as suggestRecipesFlow } from '@/ai/flows/suggest-recipes-from-ingredients';
import { suggestIngredientSubstitutions as suggestSubstitutionsFlow } from '@/ai/flows/suggest-substitutions-for-missing-ingredients';
import { adjustRecipeServings as adjustRecipeServingsFlow } from '@/ai/flows/adjust-recipe-servings';
import { Recipe } from '@/lib/types';
import { unstable_cache } from 'next/cache';
import { slugify } from '@/lib/utils';

async function _suggestRecipesFromIngredients(ingredients: string): Promise<Recipe[]> {
  if (!ingredients) return [];
  try {
    const result = await suggestRecipesFlow({ ingredients });
    return result.recipes || [];
  } catch (error) {
    console.error('Error suggesting recipes:', error);
    return [];
  }
}

const getCachedRecipes = unstable_cache(
  _suggestRecipesFromIngredients,
  ['suggested-recipes'],
  { revalidate: 3600 } // Cache for 1 hour
);

export async function suggestRecipesFromIngredients(ingredients: string): Promise<Recipe[]> {
  return getCachedRecipes(ingredients);
}

export async function getRecipeDetails(recipeSlug: string, ingredients: string): Promise<Recipe | null> {
  if (!ingredients) {
    return null;
  }
  const recipes = await getCachedRecipes(ingredients);
  const recipe = recipes.find((r) => slugify(r.name) === recipeSlug);
  return recipe || null;
}

function formatRecipeForPrompt(recipe: Recipe): string {
    return `
Recipe: ${recipe.name}

Description: ${recipe.description}

Original Servings: ${recipe.servings}

Ingredients:
${recipe.ingredients.map(ing => `- ${ing}`).join('\n')}

Instructions:
${recipe.instructions.map((inst, i) => `${i + 1}. ${inst}`).join('\n')}
    `.trim();
}

export async function getIngredientSubstitutions(
  recipe: Recipe,
  availableIngredients: string
): Promise<Record<string, string[]>> {
  try {
    const recipeString = formatRecipeForPrompt(recipe);
    const availableIngredientsArray = availableIngredients.split(',').map(s => s.trim()).filter(Boolean);
    
    const result = await suggestSubstitutionsFlow({
      recipe: recipeString,
      availableIngredients: availableIngredientsArray,
    });
    return result.substitutions;
  } catch (error) {
    console.error('Error getting ingredient substitutions:', error);
    return {};
  }
}

export async function getAdjustedIngredients(
  recipe: Recipe,
  newServings: number
): Promise<string[]> {
  try {
    const recipeString = formatRecipeForPrompt(recipe);
    const result = await adjustRecipeServingsFlow({
      recipe: recipeString,
      newServings,
    });
    return result.adjustedIngredients;
  } catch (error) {
    console.error('Error adjusting ingredients:', error);
    return [];
  }
}
