import { Suspense } from 'react';
import { suggestRecipesFromIngredients } from '@/app/actions';
import IngredientSearch from '@/components/ingredient-search';
import RecipeCard from '@/components/recipe-card';
import { Skeleton } from '@/components/ui/skeleton';
import { Utensils } from 'lucide-react';
import { Recipe } from '@/lib/types';
import AnimatedGrid from '@/components/animated-grid';

export default function Home({
  searchParams,
}: {
  searchParams?: {
    ingredients?: string;
  };
}) {
  const ingredients = searchParams?.ingredients || '';

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          What's in your fridge?
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Enter the ingredients you have, and we'll suggest delicious recipes for you to cook.
        </p>
      </div>

      <IngredientSearch initialValue={ingredients} />

      <Suspense key={ingredients} fallback={<RecipeGridSkeleton />}>
        <RecipeResults ingredients={ingredients} />
      </Suspense>
    </div>
  );
}

async function RecipeResults({ ingredients }: { ingredients: string }) {
  if (!ingredients) {
    return (
      <div className="mt-16 flex flex-col items-center justify-center text-center">
        <Utensils className="h-16 w-16 text-muted-foreground" />
        <h3 className="mt-4 text-2xl font-semibold text-foreground">Ready to cook?</h3>
        <p className="mt-2 text-muted-foreground">
          Start by entering some ingredients above.
        </p>
      </div>
    );
  }

  const recipes = await suggestRecipesFromIngredients(ingredients);

  if (recipes.length === 0) {
    return (
      <div className="mt-16 text-center text-muted-foreground">
        <p>No recipes found for these ingredients. Try some different ones!</p>
      </div>
    );
  }

  return (
    <>
      <h2 className="mt-12 text-center font-headline text-3xl font-bold tracking-tight text-foreground">
        Recipe Suggestions
      </h2>
      <AnimatedGrid className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {recipes.map((recipe: Recipe, index) => (
          <RecipeCard
            key={`${recipe.name}-${index}`}
            recipe={recipe}
            availableIngredients={ingredients}
            index={index}
          />
        ))}
      </AnimatedGrid>
    </>
  );
}


function RecipeGridSkeleton() {
  return (
    <>
       <h2 className="mt-12 text-center font-headline text-3xl font-bold tracking-tight text-foreground">
        Finding Recipes...
      </h2>
      <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex flex-col space-y-3">
            <Skeleton className="h-[200px] w-full rounded-xl" />
            <div className="space-y-2">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
