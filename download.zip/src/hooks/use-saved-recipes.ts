'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Recipe } from '@/lib/types';
import { useToast } from './use-toast';

const STORAGE_KEY = 'fridgetarian_saved_recipes';

export function useSavedRecipes() {
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    try {
      const item = window.localStorage.getItem(STORAGE_KEY);
      if (item) {
        setSavedRecipes(JSON.parse(item));
      }
    } catch (error) {
      console.error('Failed to parse saved recipes from localStorage', error);
      setSavedRecipes([]);
    }
  }, []);

  const updateStorage = (recipes: Recipe[]) => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(recipes));
      setSavedRecipes(recipes);
    } catch (error) {
      console.error('Failed to save recipes to localStorage', error);
    }
  };

  const addRecipe = useCallback((recipe: Recipe) => {
    const newRecipes = [...savedRecipes, recipe];
    updateStorage(newRecipes);
    toast({
        title: "Recipe Saved!",
        description: `${recipe.name} has been added to your collection.`,
    });
  }, [savedRecipes, toast]);

  const removeRecipe = useCallback((recipeName: string) => {
    const newRecipes = savedRecipes.filter(r => r.name !== recipeName);
    updateStorage(newRecipes);
    toast({
        title: "Recipe Removed",
        description: `${recipeName} has been removed from your collection.`,
    });
  }, [savedRecipes, toast]);

  const isRecipeSaved = useCallback((recipeName: string) => {
    return savedRecipes.some(r => r.name === recipeName);
  }, [savedRecipes]);

  const clearSavedRecipes = useCallback(() => {
    updateStorage([]);
     toast({
        title: "All Cleared",
        description: "Your saved recipes have been cleared.",
        variant: "destructive",
    });
  }, []);

  return { savedRecipes, addRecipe, removeRecipe, isRecipeSaved, clearSavedRecipes };
}
