'use client';

import { useRouter } from 'next/navigation';
import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { FormEvent, useState, useTransition } from 'react';
import { Loader2 } from 'lucide-react';

export default function IngredientSearch({ initialValue }: { initialValue: string }) {
  const router = useRouter();
  const [inputValue, setInputValue] = useState(initialValue);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const ingredients = inputValue.trim();
    startTransition(() => {
      router.push(`/?ingredients=${encodeURIComponent(ingredients)}`);
    });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="mx-auto mt-8 max-w-2xl"
    >
      <div className="relative">
        <Textarea
          name="ingredients"
          placeholder="e.g., chicken breast, tomatoes, basil, mozzarella..."
          className="rounded-lg border-2 p-4 pr-12 text-base shadow-sm focus:ring-accent"
          rows={3}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          disabled={isPending}
        />
        <Button
          type="submit"
          size="lg"
          className="absolute bottom-3 right-3 bg-accent hover:bg-accent/90"
          disabled={isPending || !inputValue.trim()}
        >
          {isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Search className="mr-2 h-4 w-4" />
          )}
          Find Recipes
        </Button>
      </div>
       <p className="mt-2 text-center text-xs text-muted-foreground">
        Separate ingredients with a comma.
      </p>
    </form>
  );
}
