'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChefHat, Bookmark } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Header() {
  const pathname = usePathname();

  const navItems = [
    { href: '/', label: 'Home', icon: ChefHat },
    { href: '/saved', label: 'Saved Recipes', icon: Bookmark },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <ChefHat className="h-6 w-6 text-accent" />
          <span className="font-bold sm:inline-block font-headline text-lg">
            Fridgetarian
          </span>
        </Link>
        <nav className="flex items-center gap-4 text-sm lg:gap-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'transition-colors hover:text-foreground/80 flex items-center gap-2',
                pathname === item.href
                  ? 'text-foreground font-semibold'
                  : 'text-foreground/60'
              )}
            >
              <item.icon className="h-4 w-4" />
              <span className="hidden sm:inline-block">{item.label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
