import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { slugify } from '@/lib/utils';
import { ArrowRight } from 'lucide-react';
import { Recipe } from '@/lib/types';

type RecipeCardProps = {
  recipe: Recipe;
  availableIngredients: string;
  index: number;
};

export default function RecipeCard({ recipe, availableIngredients, index }: RecipeCardProps) {
  const slug = slugify(recipe.name);
  const placeholder = PlaceHolderImages[index % PlaceHolderImages.length];

  return (
    <Link
      href={`/recipe/${slug}?ingredients=${encodeURIComponent(availableIngredients)}`}
      className="group"
    >
      <Card className="h-full overflow-hidden transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-1">
        <CardHeader className="p-0">
          <div className="relative h-48 w-full">
            <Image
              src={placeholder.imageUrl}
              alt={recipe.name}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              data-ai-hint={placeholder.imageHint}
            />
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <CardTitle className="font-headline text-lg font-bold leading-snug">
            {recipe.name}
          </CardTitle>
          <div className="mt-4 flex items-center text-sm font-semibold text-accent">
            View Recipe
            <ArrowRight className="ml-1 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
