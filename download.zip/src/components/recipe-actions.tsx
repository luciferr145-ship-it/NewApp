'use client';

import { useState, useTransition } from 'react';
import { Bookmark, Sparkles, Loader2, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSavedRecipes } from '@/hooks/use-saved-recipes';
import { Recipe } from '@/lib/types';
import { getIngredientSubstitutions } from '@/app/actions';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Badge } from './ui/badge';

type RecipeActionsProps = {
  recipe: Recipe;
  availableIngredients: string;
};

export default function RecipeActions({ recipe, availableIngredients }: RecipeActionsProps) {
  const { isRecipeSaved, addRecipe, removeRecipe } = useSavedRecipes();
  const [substitutions, setSubstitutions] = useState<Record<string, string[]>>({});
  const [isPending, startTransition] = useTransition();
  const [hasSearched, setHasSearched] = useState(false);

  const saved = isRecipeSaved(recipe.name);

  const handleToggleSave = () => {
    if (saved) {
      removeRecipe(recipe.name);
    } else {
      addRecipe(recipe);
    }
  };

  const handleFindSubstitutions = () => {
    startTransition(async () => {
      const result = await getIngredientSubstitutions(recipe, availableIngredients);
      setSubstitutions(result);
      setHasSearched(true);
    });
  };

  const missingIngredients = Object.keys(substitutions);

  return (
    <div className="flex items-center gap-2">
      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="bg-background/80 hover:bg-background" onClick={handleFindSubstitutions}>
            <Sparkles className="mr-2 h-4 w-4" />
            Substitutions
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-accent" />
              Ingredient Substitutions
            </DialogTitle>
            <DialogDescription>
              AI-powered suggestions for ingredients you might be missing.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 space-y-4">
            {isPending ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-accent" />
              </div>
            ) : hasSearched && missingIngredients.length > 0 ? (
              <div className='max-h-[60vh] overflow-y-auto pr-2 space-y-4'>
                {missingIngredients.map((ingredient) => (
                  <div key={ingredient} className="rounded-lg border p-4">
                    <h4 className="font-semibold">Missing: <Badge variant="secondary">{ingredient}</Badge></h4>
                    {substitutions[ingredient].length > 0 ? (
                      <ul className="mt-2 list-disc list-inside text-sm text-muted-foreground">
                        {substitutions[ingredient].map((sub, i) => (
                          <li key={i}>Substitute with <span className='font-semibold text-foreground'>{sub}</span></li>
                        ))}
                      </ul>
                    ) : (
                      <p className="mt-2 text-sm text-muted-foreground">No suitable substitutions found from your ingredients.</p>
                    )}
                  </div>
                ))}
              </div>
            ) : hasSearched ? (
              <Alert>
                <Lightbulb className="h-4 w-4" />
                <AlertTitle>All Good!</AlertTitle>
                <AlertDescription>
                  It looks like you have all the ingredients for this recipe!
                </AlertDescription>
              </Alert>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
      <Button
        variant="outline"
        size="icon"
        onClick={handleToggleSave}
        className="bg-background/80 hover:bg-background"
        aria-label={saved ? 'Unsave recipe' : 'Save recipe'}
      >
        <Bookmark
          className={`h-5 w-5 transition-all ${
            saved ? 'fill-accent text-accent' : 'text-foreground'
          }`}
        />
      </Button>
    </div>
  );
}
