import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-substitutions-for-missing-ingredients.ts';
import '@/ai/flows/suggest-recipes-from-ingredients.ts';
import '@/ai/flows/adjust-recipe-servings.ts';
