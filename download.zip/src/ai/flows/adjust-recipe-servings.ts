'use server';

/**
 * @fileOverview Adjusts recipe ingredients for a new serving size.
 * - adjustRecipeServings - A function that scales recipe ingredients.
 * - AdjustRecipeServingsInput - The input type for the function.
 * - AdjustRecipeServingsOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AdjustRecipeServingsInputSchema = z.object({
  recipe: z.string().describe('The full recipe text, including original ingredients and instructions.'),
  newServings: z.number().describe('The desired number of servings.'),
});
export type AdjustRecipeServingsInput = z.infer<typeof AdjustRecipeServingsInputSchema>;

const AdjustRecipeServingsOutputSchema = z.object({
    adjustedIngredients: z.array(z.string()).describe('The list of ingredients with quantities adjusted for the new serving size.'),
});
export type AdjustRecipeServingsOutput = z.infer<typeof AdjustRecipeServingsOutputSchema>;

export async function adjustRecipeServings(
  input: AdjustRecipeServingsInput
): Promise<AdjustRecipeServingsOutput> {
  return adjustRecipeServingsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'adjustRecipeServingsPrompt',
  input: {schema: AdjustRecipeServingsInputSchema},
  output: {schema: AdjustRecipeServingsOutputSchema},
  prompt: `You are a recipe scaling expert. Given the following recipe and a new desired number of servings, adjust the ingredient quantities accordingly.

Original Recipe:
{{{recipe}}}

New desired servings: {{{newServings}}}

Analyze the original ingredients and scale their quantities to match the new serving size. Provide only the adjusted list of ingredients. Your response must be a valid JSON object that adheres to the provided schema. Do not include instructions or any other text, only the adjusted ingredients.`,
});

const adjustRecipeServingsFlow = ai.defineFlow(
  {
    name: 'adjustRecipeServingsFlow',
    inputSchema: AdjustRecipeServingsInputSchema,
    outputSchema: AdjustRecipeServingsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
