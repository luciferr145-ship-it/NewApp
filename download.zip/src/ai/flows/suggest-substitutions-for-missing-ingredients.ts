// src/ai/flows/suggest-substitutions-for-missing-ingredients.ts
'use server';

/**
 * @fileOverview This file defines a Genkit flow that suggests ingredient substitutions for missing ingredients in a recipe.
 *
 * - suggestIngredientSubstitutions - A function that takes a recipe and a list of available ingredients and returns suggestions for substituting missing ingredients.
 * - SuggestIngredientSubstitutionsInput - The input type for the suggestIngredientSubstitutions function.
 * - SuggestIngredientSubstitutionsOutput - The output type for the suggestIngredientSubstitutions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestIngredientSubstitutionsInputSchema = z.object({
  recipe: z.string().describe('The recipe for which to suggest substitutions.'),
  availableIngredients: z
    .array(z.string())
    .describe('The ingredients that the user has available.'),
});
export type SuggestIngredientSubstitutionsInput = z.infer<
  typeof SuggestIngredientSubstitutionsInputSchema
>;

const SuggestIngredientSubstitutionsOutputSchema = z.object({
  substitutions: z
    .record(z.string(), z.array(z.string()))
    .describe(
      'A map of missing ingredients to suggested substitutions based on available ingredients.'
    ),
});
export type SuggestIngredientSubstitutionsOutput = z.infer<
  typeof SuggestIngredientSubstitutionsOutputSchema
>;

export async function suggestIngredientSubstitutions(
  input: SuggestIngredientSubstitutionsInput
): Promise<SuggestIngredientSubstitutionsOutput> {
  return suggestIngredientSubstitutionsFlow(input);
}

const suggestIngredientSubstitutionsPrompt = ai.definePrompt({
  name: 'suggestIngredientSubstitutionsPrompt',
  input: {schema: SuggestIngredientSubstitutionsInputSchema},
  output: {schema: SuggestIngredientSubstitutionsOutputSchema},
  prompt: `You are a helpful recipe assistant. Given the following recipe and a list of available ingredients, suggest substitutions for any missing ingredients using only the available ingredients.

Recipe:
{{recipe}}

Available Ingredients:
{{#each availableIngredients}}- {{this}}\n{{/each}}

Provide the substitutions in a JSON format where the keys are the missing ingredients and the values are arrays of suggested substitutions.
Ensure that the suggested substitutions make sense for the recipe and are reasonable alternatives. Return an empty array if you cannot suggest a suitable replacement.
{
  "missing_ingredient": ["substitution1", "substitution2"],
  "another_missing_ingredient": ["substitution3"]
}
`,
});

const suggestIngredientSubstitutionsFlow = ai.defineFlow(
  {
    name: 'suggestIngredientSubstitutionsFlow',
    inputSchema: SuggestIngredientSubstitutionsInputSchema,
    outputSchema: SuggestIngredientSubstitutionsOutputSchema,
  },
  async input => {
    const {output} = await suggestIngredientSubstitutionsPrompt(input);
    return output!;
  }
);
