import { z } from 'zod';

export const RecipeSchema = z.object({
  name: z.string().describe('The name of the recipe.'),
  description: z.string().describe('A short, appetizing description of the dish.'),
  cookTimeMinutes: z.number().describe('Estimated total cooking time in minutes.'),
  servings: z.string().describe("Number of servings the recipe makes, e.g., '2-4'."),
  ingredients: z.array(z.string()).describe('List of ingredients with measurements.'),
  instructions: z.array(z.string()).describe('Step-by-step cooking instructions.'),
});

export type Recipe = z.infer<typeof RecipeSchema>;
